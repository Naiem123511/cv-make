<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
// including the database connection file
include_once("connection.php");

if(isset($_POST['Submit']))
{	
	
	
	$name = $_POST['name'];
	$address = $_POST['address'];
	$phone = $_POST['phone'];	
	$currentPosition = $_POST['current_position'];	
	$email = $_POST['email'];	
	$about = $_POST['about'];	
	$userId =  $_SESSION['id'];
	
	// checking empty fields
		$result = mysqli_query($mysqli, "INSERT INTO cv_profile(name, address, phone, username, 
		position, email, about) 
		VALUES('$name','$address','$phone', '$userId', '$currentPosition', '$email', '$about')");
		
		//redirectig to the display page. In our case, it is view.php
		echo "<br><font color='green'>Data added successfully.<br>";
		header("Location: experience.php");
}
?>
<html>
<head>
	<title>Add Data</title>
</head>

<body>
	<a href="index.php">Home</a> | <a href="cv.php">View CV</a> | <a href="logout.php">Logout</a>
	<br/><br/>

	<form action="add.php" method="post" name="form1">
		<table width="25%" border="0">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="name"></td>
			</tr>
			<tr> 
				<td>Address</td>
				<td><input type="text" name="address"></td>
			</tr>
			<tr> 
				<td>Phone</td>
				<td><input type="text" name="phone"></td>
			</tr>
			<tr> 
				<td>Current Position</td>
				<td><input type="text" name="current_position"></td>
			</tr> 
				<td>email</td>
				<td><input type="text" name="email"></td>
			</tr> 
				<td>about</td>
				<td><input type="text" name="about"></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
		</table>
	</form>
</body>
</html>

